This model has not been textured,
This model has been made in Blender and is made by ME and this ME is new to blender.

This model was originally made for a school animation about the life of an police officer
but the model was going to get deleted due to another model (Better then this model RIP)

have a nice day













why no one is eventually gonna download this
you dont know that
maybe i do
what
why are you writing with your self?
i dont know...

TO BE CONTINUED



















SUCH EMPTY




